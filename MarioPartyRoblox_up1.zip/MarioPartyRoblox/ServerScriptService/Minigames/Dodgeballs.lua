local RunService = game:GetService("RunService")

local module = {}
module.Name = "Уклонись от шаров"
module.Duration = 45

local BASE_Y = 400
local SIZE = 60
local HALF = 35 -- откуда вылетают шары (чуть за краем арены)

local function getRoot(plr)
	local char = plr.Character
	return char and char:FindFirstChild("HumanoidRootPart")
end

function module.Run(participants)
	local arena = Instance.new("Folder")
	arena.Name = "Arena"
	arena.Parent = workspace

	local floor = Instance.new("Part")
	floor.Size = Vector3.new(SIZE, 1, SIZE)
	floor.Anchored = true
	floor.Position = Vector3.new(0, BASE_Y, 0)
	floor.Parent = arena

	local alive = {}
	for _, plr in participants do
		if getRoot(plr) then
			table.insert(alive, plr)
			plr.Character:PivotTo(CFrame.new(math.random(-20, 20), BASE_Y + 5, math.random(-20, 20)))
		end
	end

	local balls = {}
	local eliminated = {}

	local function spawnBall(elapsed)
		local side = math.random(4)
		local pos
		if side == 1 then
			pos = Vector3.new(-HALF, 0, math.random(-HALF, HALF))
		elseif side == 2 then
			pos = Vector3.new(HALF, 0, math.random(-HALF, HALF))
		elseif side == 3 then
			pos = Vector3.new(math.random(-HALF, HALF), 0, -HALF)
		else
			pos = Vector3.new(math.random(-HALF, HALF), 0, HALF)
		end
		pos += Vector3.new(0, BASE_Y + 3, 0)

		local target = Vector3.new(math.random(-20, 20), BASE_Y + 3, math.random(-20, 20))

		local part = Instance.new("Part")
		part.Shape = Enum.PartType.Ball
		part.Size = Vector3.new(4, 4, 4)
		part.Color = Color3.fromRGB(255, 60, 60)
		part.Material = Enum.Material.Neon
		part.Anchored = true
		part.CanCollide = false
		part.CanTouch = false
		part.Position = pos
		part.Parent = arena

		table.insert(balls, {
			part = part,
			dir = (target - pos).Unit,
			speed = 30 + elapsed * 0.7, -- со временем шары быстрее
			born = os.clock(),
		})
	end

	local startTime = os.clock()
	local spawnTimer = 0

	while #alive > 1 and os.clock() - startTime < module.Duration do
		local dt = RunService.Heartbeat:Wait()
		local elapsed = os.clock() - startTime

		-- со временем шары появляются чаще
		spawnTimer += dt
		if spawnTimer >= math.max(0.25, 0.8 - elapsed * 0.01) then
			spawnTimer = 0
			spawnBall(elapsed)
		end

		-- двигаем шары
		for i = #balls, 1, -1 do
			local b = balls[i]
			b.part.Position += b.dir * b.speed * dt
			if os.clock() - b.born > 8 then
				b.part:Destroy()
				table.remove(balls, i)
			end
		end

		-- проверяем попадания и падения
		for i = #alive, 1, -1 do
			local plr = alive[i]
			local root = getRoot(plr)
			local out = (root == nil) or root.Position.Y < BASE_Y - 20
			if not out then
				for _, b in balls do
					if (b.part.Position - root.Position).Magnitude < 4 then
						out = true
						break
					end
				end
			end
			if out then
				table.insert(eliminated, plr)
				table.remove(alive, i)
				local hum = plr.Character and plr.Character:FindFirstChildOfClass("Humanoid")
				if hum then hum.Health = 0 end
			end
		end
	end

	-- выжившие первыми, затем выбывшие с конца
	local results = {}
	for _, plr in alive do
		if plr.Parent then table.insert(results, plr) end
	end
	for i = #eliminated, 1, -1 do
		if eliminated[i].Parent then table.insert(results, eliminated[i]) end
	end

	arena:Destroy()
	return results
end

return module
