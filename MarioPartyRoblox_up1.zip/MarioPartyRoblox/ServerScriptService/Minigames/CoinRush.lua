local Players = game:GetService("Players")

local module = {}
module.Name = "Сбор монет"
module.Duration = 30

local BASE_Y = 200
local SIZE = 80
local COINS = 25

local function getRoot(plr)
	local char = plr.Character
	return char and char:FindFirstChild("HumanoidRootPart")
end

function module.Run(participants)
	local arena = Instance.new("Folder")
	arena.Name = "Arena"
	arena.Parent = workspace

	local floor = Instance.new("Part")
	floor.Size = Vector3.new(SIZE, 1, SIZE)
	floor.Anchored = true
	floor.Position = Vector3.new(0, BASE_Y, 0)
	floor.Parent = arena

	-- игроки и их счёт
	local scores = {}
	local players = {}
	for _, plr in participants do
		if getRoot(plr) then
			scores[plr] = 0
			table.insert(players, plr)
			plr.Character:PivotTo(CFrame.new(math.random(-30, 30), BASE_Y + 5, math.random(-30, 30)))
		end
	end

	-- монеты: после подбора перемещаются в новое место
	local connections = {}
	local function placeCoin(coin)
		coin.Position = Vector3.new(math.random(-35, 35), BASE_Y + 3, math.random(-35, 35))
	end

	for _ = 1, COINS do
		local coin = Instance.new("Part")
		coin.Shape = Enum.PartType.Cylinder
		coin.Size = Vector3.new(0.5, 3, 3)
		coin.Orientation = Vector3.new(0, 0, 90)
		coin.Color = Color3.fromRGB(255, 200, 0)
		coin.Material = Enum.Material.Neon
		coin.Anchored = true
		coin.CanCollide = false
		placeCoin(coin)
		coin.Parent = arena

		table.insert(connections, coin.Touched:Connect(function(hit)
			local plr = Players:GetPlayerFromCharacter(hit.Parent)
			if plr and scores[plr] then
				scores[plr] += 1
				placeCoin(coin)
			end
		end))
	end

	local startTime = os.clock()
	while os.clock() - startTime < module.Duration do
		task.wait(0.5)
		-- упавших возвращаем на арену
		for _, plr in players do
			local root = getRoot(plr)
			if root and root.Position.Y < BASE_Y - 20 then
				plr.Character:PivotTo(CFrame.new(0, BASE_Y + 5, 0))
			end
		end
	end

	for _, c in connections do c:Disconnect() end

	-- больше монет = выше место
	table.sort(players, function(a, b) return scores[a] > scores[b] end)
	local results = {}
	for _, plr in players do
		if plr.Parent then table.insert(results, plr) end
	end

	arena:Destroy()
	return results
end

return module
