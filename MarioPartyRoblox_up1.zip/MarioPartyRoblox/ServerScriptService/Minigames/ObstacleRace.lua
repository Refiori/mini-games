local module = {}
module.Name = "Гонка по платформам"
module.Duration = 70

local BASE_Y = 300
local TILES = 18
local TILE_LEN = 8
local GAP = 5

local function getRoot(plr)
	local char = plr.Character
	return char and char:FindFirstChild("HumanoidRootPart")
end

function module.Run(participants)
	local arena = Instance.new("Folder")
	arena.Name = "Arena"
	arena.Parent = workspace

	local function makePart(size, pos, color)
		local p = Instance.new("Part")
		p.Size = size
		p.Anchored = true
		p.Position = pos
		if color then p.Color = color end
		p.Parent = arena
		return p
	end

	-- стартовая площадка
	makePart(Vector3.new(24, 1, 24), Vector3.new(-10, BASE_Y, 0), Color3.fromRGB(80, 160, 255))

	-- платформы зигзагом с промежутками
	local x = 8
	for i = 1, TILES do
		local z = math.random(-6, 6)
		makePart(Vector3.new(TILE_LEN, 1, 10), Vector3.new(x + TILE_LEN / 2, BASE_Y, z))
		x += TILE_LEN + GAP
	end

	-- финиш
	local finishX = x + 6
	makePart(Vector3.new(24, 1, 24), Vector3.new(finishX + 6, BASE_Y, 0), Color3.fromRGB(80, 255, 120))

	local startCF = CFrame.new(-10, BASE_Y + 5, 0)

	local players = {}
	for _, plr in participants do
		if getRoot(plr) then
			table.insert(players, plr)
			plr.Character:PivotTo(CFrame.new(-16 + math.random(0, 10), BASE_Y + 5, math.random(-8, 8)))
		end
	end

	local finished, isFinished, progress = {}, {}, {}
	local startTime = os.clock()

	while os.clock() - startTime < module.Duration and #finished < #players do
		task.wait(0.2)
		for _, plr in players do
			if not isFinished[plr] then
				local root = getRoot(plr)
				if root then
					local px = root.Position.X
					progress[plr] = math.max(progress[plr] or -100, px)
					if px >= finishX and root.Position.Y > BASE_Y - 10 then
						isFinished[plr] = true
						table.insert(finished, plr)
					elseif root.Position.Y < BASE_Y - 30 then
						plr.Character:PivotTo(startCF) -- упал: возвращаем на старт
					end
				end
			end
		end
	end

	-- сначала финишировавшие, потом остальные по пройденному пути
	local rest = {}
	for _, plr in players do
		if not isFinished[plr] then table.insert(rest, plr) end
	end
	table.sort(rest, function(a, b) return (progress[a] or -100) > (progress[b] or -100) end)

	local results = {}
	for _, plr in finished do
		if plr.Parent then table.insert(results, plr) end
	end
	for _, plr in rest do
		if plr.Parent then table.insert(results, plr) end
	end

	arena:Destroy()
	return results
end

return module
