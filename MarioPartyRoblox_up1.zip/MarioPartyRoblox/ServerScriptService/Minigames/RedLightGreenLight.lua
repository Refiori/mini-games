local ReplicatedStorage = game:GetService("ReplicatedStorage")

local module = {}
module.Name = "Красный свет, зелёный свет"
module.Duration = 60

local BASE_Y = 500
local LENGTH = 120
local WIDTH = 40
local FINISH_X = LENGTH - 5
local GREEN = Color3.fromRGB(60, 255, 90)
local RED = Color3.fromRGB(255, 50, 50)

local function getRoot(plr)
	local char = plr.Character
	return char and char:FindFirstChild("HumanoidRootPart")
end

function module.Run(participants)
	local statusEvent = ReplicatedStorage:FindFirstChild("StatusUpdate")
	local function say(text)
		if statusEvent then statusEvent:FireAllClients(text, 0) end
	end

	local arena = Instance.new("Folder")
	arena.Name = "Arena"
	arena.Parent = workspace

	local floor = Instance.new("Part")
	floor.Size = Vector3.new(LENGTH + 20, 1, WIDTH)
	floor.Anchored = true
	floor.Position = Vector3.new(LENGTH / 2, BASE_Y, 0)
	floor.Parent = arena

	-- линия финиша
	local line = Instance.new("Part")
	line.Size = Vector3.new(2, 0.2, WIDTH)
	line.Anchored = true
	line.CanCollide = false
	line.Color = Color3.fromRGB(255, 255, 255)
	line.Position = Vector3.new(FINISH_X, BASE_Y + 0.6, 0)
	line.Parent = arena

	-- «светофор»
	local light = Instance.new("Part")
	light.Shape = Enum.PartType.Ball
	light.Size = Vector3.new(12, 12, 12)
	light.Anchored = true
	light.CanCollide = false
	light.Material = Enum.Material.Neon
	light.Color = GREEN
	light.Position = Vector3.new(LENGTH + 5, BASE_Y + 14, 0)
	light.Parent = arena

	local startCF = CFrame.new(3, BASE_Y + 5, 0)

	local players = {}
	for _, plr in participants do
		if getRoot(plr) then
			table.insert(players, plr)
			plr.Character:PivotTo(CFrame.new(math.random(0, 6), BASE_Y + 5, math.random(-15, 15)))
		end
	end

	local finished, isFinished, progress = {}, {}, {}
	local green = true
	local startTime = os.clock()
	local phaseEnd = startTime + 3
	local redStart = 0
	say("ЗЕЛЁНЫЙ СВЕТ — беги!")

	while os.clock() - startTime < module.Duration and #finished < #players do
		task.wait(0.1)
		local now = os.clock()

		-- смена света
		if now >= phaseEnd then
			green = not green
			if green then
				light.Color = GREEN
				phaseEnd = now + math.random(3, 5)
				say("ЗЕЛЁНЫЙ СВЕТ — беги!")
			else
				light.Color = RED
				phaseEnd = now + math.random(2, 4)
				redStart = now
				say("КРАСНЫЙ СВЕТ — стоп!")
			end
		end

		for _, plr in players do
			if not isFinished[plr] then
				local root = getRoot(plr)
				if root then
					local px = root.Position.X
					progress[plr] = math.max(progress[plr] or 0, px)

					if px >= FINISH_X and root.Position.Y > BASE_Y - 10 then
						isFinished[plr] = true
						table.insert(finished, plr)
					elseif root.Position.Y < BASE_Y - 20 then
						plr.Character:PivotTo(startCF)
					elseif not green and now - redStart > 0.5 then
						-- на красном двигаться нельзя: возвращаем на старт
						local v = root.AssemblyLinearVelocity
						if Vector3.new(v.X, 0, v.Z).Magnitude > 2 then
							plr.Character:PivotTo(startCF)
						end
					end
				end
			end
		end
	end

	local rest = {}
	for _, plr in players do
		if not isFinished[plr] then table.insert(rest, plr) end
	end
	table.sort(rest, function(a, b) return (progress[a] or 0) > (progress[b] or 0) end)

	local results = {}
	for _, plr in finished do
		if plr.Parent then table.insert(results, plr) end
	end
	for _, plr in rest do
		if plr.Parent then table.insert(results, plr) end
	end

	arena:Destroy()
	return results
end

return module
